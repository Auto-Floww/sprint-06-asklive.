# Sprint 06 — AskLive / FalaQ

Solução dos tickets 009–012 de https://nato-re.github.io/atividades/sprint-06

**ATENÇÃO:** Este pacote é um conjunto de arquivos e trechos para integrar ao repositório Laravel **existente**. Não é um projeto Laravel independente; não substitua cegamente os arquivos existentes, pois isso pode apagar funcionalidades de outras sprints.

## Aplicação

1. Abra o projeto original, confira a branch `v5.0-pivot-starter` e faça uma branch de trabalho: `git switch v5.0-pivot-starter` e `git switch -c sprint-06-upvotes`.
2. Copie `database/migrations/2026_10_23_000000_create_pergunta_user_table.php` para a pasta `database/migrations/` do projeto. Verifique se os nomes de tabelas reais são `perguntas` e `users` (padrão Laravel), especialmente se o projeto usa pluralização personalizada.
3. Use os arquivos na pasta `trechos/` como instruções de inserção em arquivos existentes. Preserve os outros métodos, rotas, campos e HTML.
4. Em `EventoController`, ajuste a consulta e o `return view` ao código original. Na view, use o loop do exemplo ou encaixe a UI no loop já existente (não renderize o loop duas vezes).
5. Rode `php artisan migrate` e `php artisan test --filter=UpvotePerguntaTest` no projeto Laravel real.
6. Se os testes falharem, compare a estrutura do projeto, o nome das colunas e as mensagens do teste. **Esta implementação ainda não foi executada ou validada contra o repositório original**, pois ele não foi disponibilizado.

## Publicação no GitHub (quando o repo estiver acessível)

```bash
git add .
git commit -m "feat: implementa upvotes e ranking de perguntas (sprint 06)"
git push -u origin sprint-06-upvotes
```

A branch `v5.0-pivot-starter` é a base exigida pela atividade. O pacote não cria branch nem envia alterações automaticamente.
